import os

f=open('save_selected_files.dat','r')

l_f=f.readlines()

l=len(l_f)

for i in range(0,l):
    
    full_line=l_f[i].split()
    
    metal=str(full_line[0])


    s=str(full_line[1])
    

    cif='cp ../../../June_2021_fresh/cif_out_20200910/'+s+'.cif ./'
    os.system(cif)
    #for j in range(0,len(l_f[r])-1):
    #    s=s+l_f[r][j]

    s1='../../../June_2021_fresh/'+metal+'/'+s+'/no_vs_name.dat'
    g=open(s1,'r')
    l_g=g.readlines()
    
    a=l_g[0].split()
    b=int(a[0]) 
    for j in range(0,b):
        k=j+1

        link=len(a[k])
        linker_image=''
        for abc in range(0,link-3):
            linker_image=linker_image+a[k][abc]
        linker_image=linker_image+'png'

        s1='cp ../../../June_2021_fresh/'+metal+'/'+s+'/'+linker_image+' ./'+s+linker_image

        os.system(s1)


        s2="Image('./data/"+s+linker_image+"')"
        s2="Image('./"+s+linker_image+"')"
        print s2
        print ('\n')

    #s3="Image('./data/know_your_atom.png')"
    #print s3


    #s4="nutils.viewer('./data/"+s+".cif')"
    s4="nutils.viewer('./"+s+".cif')"
    print s4
    print ('\n')
    mof="mof_"+str(i+1)
    s5="temperature_"+mof+"_Celsius  = 100.0 #@param {type:'number'}"
    s6="time_"+mof+"_hours  = 25.0 #@param {type:'number'}"
    s71="first_solvent_"+mof+" = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']"
    s72="second_solvent_"+mof+" = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']"
    s73="third_solvent_"+mof+" = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']"


    s8="additive_"+mof+" = 'no additive' #@param ['no additive', 'acid', 'base']"


    s9="counter_ion_"+mof+" =  'CL' #@param {type:'string'}"

        
    s10="concentration_metal_"+mof+"_mol_per_liter  = 10.0 #@param {type:'number'}"
    s11="concentration_first_linker_"+mof+"_mol_per_liter  = 12.0 #@param {type:'number'}"
    s111="concentration_second_linker_"+mof+"_mol_per_liter  = 0.0 #@param {type:'number'}"

    s12="are_you_sure_about_your_selction_"+mof+" = 'no' #@param ['no', 'yes']"

    s13="what_makes_you_so_sure_or_unsure_"+mof+" =  'Found a similar MOF' #@param {type:'string'}" 



        

    s14="results['"+mof+"'] = {}"

    s15="results['"+mof+"']['temperature']=temperature_"+mof+"_Celsius"
    s16="results['"+mof+"']['time']=time_"+mof+"_hours"
    s17="results['"+mof+"']['solvent1']=first_solvent_"+mof
    s18="results['"+mof+"']['solvent2']=second_solvent_"+mof
    s19="results['"+mof+"']['solvent3']=third_solvent_"+mof
          
    s20="results['"+mof+"']['additive']=additive_"+mof
    s21="results['"+mof+"']['counter']=counter_ion_"+mof
    s22="results['"+mof+"']['metal']=concentration_metal_"+mof+"_mol_per_liter"
    s23="results['"+mof+"']['linker1']=concentration_first_linker_"+mof+"_mol_per_liter"
    s231="results['"+mof+"']['linker2']=concentration_second_linker_"+mof+"_mol_per_liter"
    s24="results['"+mof+"']['surely']=are_you_sure_about_your_selction_"+mof
    s25="results['"+mof+"']['additional']=what_makes_you_so_sure_or_unsure_"+mof
          



    s26= "nutils.print_choice(temperature_"+mof+"_Celsius, time_"+mof+"_hours, first_solvent_"+mof+",second_solvent_"+mof+",third_solvent_"+mof+" , counter_ion_"+mof+", concentration_metal_"+mof+"_mol_per_liter, concentration_first_linker_"+mof+"_mol_per_liter,concentration_second_linker_"+mof+"_mol_per_liter , additive_"+mof+",are_you_sure_about_your_selction_"+mof+", what_makes_you_so_sure_or_unsure_"+mof+" )"
    print s5

    print s6

    print s71
    print s72
    print s73
    print s8
    print s9
    print s10
    print s11
    print s111
    print s12
    print s13
    print s14
    print s15
    print s16
    print s17
    print s18
    print s19
    print s20
    print s21
    print s22
    print s23
    print s231
    print s24
    print s25
    print ('\n')
    print s26
    print ('\n')


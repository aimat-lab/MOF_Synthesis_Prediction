import py3Dmol



def viewer(filename):
    view = py3Dmol.view(width=400,height=400)
    with open(filename) as ifile:
        system = "".join([x for x in ifile])
    view.addModelsAsFrames(system)
    view.setStyle({'stick':{}})
    view.setBackgroundColor('0xeeeeee')
    view.zoomTo()
    view.show()



def hello(data):
    print("hello %s"%(data))


def atoms_to_html(atoms):
    'Return the html representation the atoms object as string'

    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile('r+', suffix='.html') as ntf:
        atoms.write(ntf.name, format='html')
        ntf.seek(0)
        html = ntf.read()
    return html


def save_results(results, filename = "results.txt"):
    outfile=open(filename, "w")
    for key in results.keys():
        outfile.write(str(key)+","+str(results[key]["temperature"])+","+str(results[key]["time"])+","+str(results[key]["solvent1"])+","+str(results[key]["solvent2"])+","+str(results[key]["solvent3"])+","+str(results[key]["counter"])+","+str(results[key]["metal"])+","+str(results[key]["linker1"])+","+str(results[key]["linker2"])+","+str(results[key]["additive"])+","+str(results[key]["surely"])+","+str(results[key]["additional"])+"\n")
      #outfile.write("%s %s %s %s %s %s %s %s %s %s %s %s\n"%(key,",", results[key]["temperature"],",",  results[key]["time"],",",  results[key]["solvent1"],",", results[key]["solvent2"],",", results[key]["solvent3"] ,",", results[key]["counter"],",", results[key]["metal"],",", results[key]["linker"],",", results[key]["additive"],",", results[key]["surely"],",", results[key]["additional"]))
    outfile.close()


def print_choice(T, t, s1, s2, s3, counter, metal, linker1, linker2, additive, surely, additional):
    print("Thanks for your input")
    print("Your selection was:")
    print("Temperature: %s"%(T))
    print("Time: %s"%(t))
    print("Solvent1: %s"%(s1))
    print("Solvent2: %s"%(s2))
    print("Solvent3: %s"%(s3))
    print("Counter Ion: %s"%(counter))
    print("Metal_Concentration: %s"%(metal))
    print("First_Linker_Concentration: %s"%(linker1))
    print("Second_Linker_Concentration: %s"%(linker2))
    print("Additive: %s"%(additive))
    print("Are_You_Sure_About_Your_Selection: %s"%(surely))
    print("What_Makes_You_So_Sure/Unsure: %s"%(additional))



Image('./WOPHIU01_cleansingle_linker0.png')


Image('./WOPHIU01_cleansingle_linker1.png')


nutils.viewer('./WOPHIU01_clean.cif')


temperature_mof_1_Celsius  = 100.0 #@param {type:'number'}
time_mof_1_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_1 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_1 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_1 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_1 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_1 =  'CL' #@param {type:'string'}
concentration_metal_mof_1_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_1_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_1_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_1 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_1 =  'Found a similar MOF' #@param {type:'string'}
results['mof_1'] = {}
results['mof_1']['temperature']=temperature_mof_1_Celsius
results['mof_1']['time']=time_mof_1_hours
results['mof_1']['solvent1']=first_solvent_mof_1
results['mof_1']['solvent2']=second_solvent_mof_1
results['mof_1']['solvent3']=third_solvent_mof_1
results['mof_1']['additive']=additive_mof_1
results['mof_1']['counter']=counter_ion_mof_1
results['mof_1']['metal']=concentration_metal_mof_1_mol_per_liter
results['mof_1']['linker1']=concentration_first_linker_mof_1_mol_per_liter
results['mof_1']['linker2']=concentration_second_linker_mof_1_mol_per_liter
results['mof_1']['surely']=are_you_sure_about_your_selction_mof_1
results['mof_1']['additional']=what_makes_you_so_sure_or_unsure_mof_1


nutils.print_choice(temperature_mof_1_Celsius, time_mof_1_hours, first_solvent_mof_1,second_solvent_mof_1,third_solvent_mof_1 , counter_ion_mof_1, concentration_metal_mof_1_mol_per_liter, concentration_first_linker_mof_1_mol_per_liter,concentration_second_linker_mof_1_mol_per_liter , additive_mof_1,are_you_sure_about_your_selction_mof_1, what_makes_you_so_sure_or_unsure_mof_1 )


Image('./RIDCEN_chargedsingle_linker0.png')


nutils.viewer('./RIDCEN_charged.cif')


temperature_mof_2_Celsius  = 100.0 #@param {type:'number'}
time_mof_2_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_2 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_2 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_2 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_2 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_2 =  'CL' #@param {type:'string'}
concentration_metal_mof_2_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_2_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_2_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_2 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_2 =  'Found a similar MOF' #@param {type:'string'}
results['mof_2'] = {}
results['mof_2']['temperature']=temperature_mof_2_Celsius
results['mof_2']['time']=time_mof_2_hours
results['mof_2']['solvent1']=first_solvent_mof_2
results['mof_2']['solvent2']=second_solvent_mof_2
results['mof_2']['solvent3']=third_solvent_mof_2
results['mof_2']['additive']=additive_mof_2
results['mof_2']['counter']=counter_ion_mof_2
results['mof_2']['metal']=concentration_metal_mof_2_mol_per_liter
results['mof_2']['linker1']=concentration_first_linker_mof_2_mol_per_liter
results['mof_2']['linker2']=concentration_second_linker_mof_2_mol_per_liter
results['mof_2']['surely']=are_you_sure_about_your_selction_mof_2
results['mof_2']['additional']=what_makes_you_so_sure_or_unsure_mof_2


nutils.print_choice(temperature_mof_2_Celsius, time_mof_2_hours, first_solvent_mof_2,second_solvent_mof_2,third_solvent_mof_2 , counter_ion_mof_2, concentration_metal_mof_2_mol_per_liter, concentration_first_linker_mof_2_mol_per_liter,concentration_second_linker_mof_2_mol_per_liter , additive_mof_2,are_you_sure_about_your_selction_mof_2, what_makes_you_so_sure_or_unsure_mof_2 )


Image('./AJINOY_cleansingle_linker0.png')


Image('./AJINOY_cleansingle_linker3.png')


nutils.viewer('./AJINOY_clean.cif')


temperature_mof_3_Celsius  = 100.0 #@param {type:'number'}
time_mof_3_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_3 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_3 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_3 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_3 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_3 =  'CL' #@param {type:'string'}
concentration_metal_mof_3_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_3_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_3_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_3 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_3 =  'Found a similar MOF' #@param {type:'string'}
results['mof_3'] = {}
results['mof_3']['temperature']=temperature_mof_3_Celsius
results['mof_3']['time']=time_mof_3_hours
results['mof_3']['solvent1']=first_solvent_mof_3
results['mof_3']['solvent2']=second_solvent_mof_3
results['mof_3']['solvent3']=third_solvent_mof_3
results['mof_3']['additive']=additive_mof_3
results['mof_3']['counter']=counter_ion_mof_3
results['mof_3']['metal']=concentration_metal_mof_3_mol_per_liter
results['mof_3']['linker1']=concentration_first_linker_mof_3_mol_per_liter
results['mof_3']['linker2']=concentration_second_linker_mof_3_mol_per_liter
results['mof_3']['surely']=are_you_sure_about_your_selction_mof_3
results['mof_3']['additional']=what_makes_you_so_sure_or_unsure_mof_3


nutils.print_choice(temperature_mof_3_Celsius, time_mof_3_hours, first_solvent_mof_3,second_solvent_mof_3,third_solvent_mof_3 , counter_ion_mof_3, concentration_metal_mof_3_mol_per_liter, concentration_first_linker_mof_3_mol_per_liter,concentration_second_linker_mof_3_mol_per_liter , additive_mof_3,are_you_sure_about_your_selction_mof_3, what_makes_you_so_sure_or_unsure_mof_3 )


Image('./QIVZEC_cleansingle_linker0.png')


Image('./QIVZEC_cleansingle_linker1.png')


nutils.viewer('./QIVZEC_clean.cif')


temperature_mof_4_Celsius  = 100.0 #@param {type:'number'}
time_mof_4_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_4 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_4 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_4 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_4 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_4 =  'CL' #@param {type:'string'}
concentration_metal_mof_4_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_4_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_4_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_4 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_4 =  'Found a similar MOF' #@param {type:'string'}
results['mof_4'] = {}
results['mof_4']['temperature']=temperature_mof_4_Celsius
results['mof_4']['time']=time_mof_4_hours
results['mof_4']['solvent1']=first_solvent_mof_4
results['mof_4']['solvent2']=second_solvent_mof_4
results['mof_4']['solvent3']=third_solvent_mof_4
results['mof_4']['additive']=additive_mof_4
results['mof_4']['counter']=counter_ion_mof_4
results['mof_4']['metal']=concentration_metal_mof_4_mol_per_liter
results['mof_4']['linker1']=concentration_first_linker_mof_4_mol_per_liter
results['mof_4']['linker2']=concentration_second_linker_mof_4_mol_per_liter
results['mof_4']['surely']=are_you_sure_about_your_selction_mof_4
results['mof_4']['additional']=what_makes_you_so_sure_or_unsure_mof_4


nutils.print_choice(temperature_mof_4_Celsius, time_mof_4_hours, first_solvent_mof_4,second_solvent_mof_4,third_solvent_mof_4 , counter_ion_mof_4, concentration_metal_mof_4_mol_per_liter, concentration_first_linker_mof_4_mol_per_liter,concentration_second_linker_mof_4_mol_per_liter , additive_mof_4,are_you_sure_about_your_selction_mof_4, what_makes_you_so_sure_or_unsure_mof_4 )


Image('./LIKGUJ_cleansingle_linker0.png')


nutils.viewer('./LIKGUJ_clean.cif')


temperature_mof_5_Celsius  = 100.0 #@param {type:'number'}
time_mof_5_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_5 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_5 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_5 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_5 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_5 =  'CL' #@param {type:'string'}
concentration_metal_mof_5_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_5_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_5_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_5 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_5 =  'Found a similar MOF' #@param {type:'string'}
results['mof_5'] = {}
results['mof_5']['temperature']=temperature_mof_5_Celsius
results['mof_5']['time']=time_mof_5_hours
results['mof_5']['solvent1']=first_solvent_mof_5
results['mof_5']['solvent2']=second_solvent_mof_5
results['mof_5']['solvent3']=third_solvent_mof_5
results['mof_5']['additive']=additive_mof_5
results['mof_5']['counter']=counter_ion_mof_5
results['mof_5']['metal']=concentration_metal_mof_5_mol_per_liter
results['mof_5']['linker1']=concentration_first_linker_mof_5_mol_per_liter
results['mof_5']['linker2']=concentration_second_linker_mof_5_mol_per_liter
results['mof_5']['surely']=are_you_sure_about_your_selction_mof_5
results['mof_5']['additional']=what_makes_you_so_sure_or_unsure_mof_5


nutils.print_choice(temperature_mof_5_Celsius, time_mof_5_hours, first_solvent_mof_5,second_solvent_mof_5,third_solvent_mof_5 , counter_ion_mof_5, concentration_metal_mof_5_mol_per_liter, concentration_first_linker_mof_5_mol_per_liter,concentration_second_linker_mof_5_mol_per_liter , additive_mof_5,are_you_sure_about_your_selction_mof_5, what_makes_you_so_sure_or_unsure_mof_5 )


Image('./XULDOZ_cleansingle_linker0.png')


nutils.viewer('./XULDOZ_clean.cif')


temperature_mof_6_Celsius  = 100.0 #@param {type:'number'}
time_mof_6_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_6 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_6 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_6 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_6 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_6 =  'CL' #@param {type:'string'}
concentration_metal_mof_6_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_6_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_6_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_6 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_6 =  'Found a similar MOF' #@param {type:'string'}
results['mof_6'] = {}
results['mof_6']['temperature']=temperature_mof_6_Celsius
results['mof_6']['time']=time_mof_6_hours
results['mof_6']['solvent1']=first_solvent_mof_6
results['mof_6']['solvent2']=second_solvent_mof_6
results['mof_6']['solvent3']=third_solvent_mof_6
results['mof_6']['additive']=additive_mof_6
results['mof_6']['counter']=counter_ion_mof_6
results['mof_6']['metal']=concentration_metal_mof_6_mol_per_liter
results['mof_6']['linker1']=concentration_first_linker_mof_6_mol_per_liter
results['mof_6']['linker2']=concentration_second_linker_mof_6_mol_per_liter
results['mof_6']['surely']=are_you_sure_about_your_selction_mof_6
results['mof_6']['additional']=what_makes_you_so_sure_or_unsure_mof_6


nutils.print_choice(temperature_mof_6_Celsius, time_mof_6_hours, first_solvent_mof_6,second_solvent_mof_6,third_solvent_mof_6 , counter_ion_mof_6, concentration_metal_mof_6_mol_per_liter, concentration_first_linker_mof_6_mol_per_liter,concentration_second_linker_mof_6_mol_per_liter , additive_mof_6,are_you_sure_about_your_selction_mof_6, what_makes_you_so_sure_or_unsure_mof_6 )


Image('./HAFSOZ_cleansingle_linker0.png')


nutils.viewer('./HAFSOZ_clean.cif')


temperature_mof_7_Celsius  = 100.0 #@param {type:'number'}
time_mof_7_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_7 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_7 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_7 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_7 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_7 =  'CL' #@param {type:'string'}
concentration_metal_mof_7_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_7_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_7_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_7 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_7 =  'Found a similar MOF' #@param {type:'string'}
results['mof_7'] = {}
results['mof_7']['temperature']=temperature_mof_7_Celsius
results['mof_7']['time']=time_mof_7_hours
results['mof_7']['solvent1']=first_solvent_mof_7
results['mof_7']['solvent2']=second_solvent_mof_7
results['mof_7']['solvent3']=third_solvent_mof_7
results['mof_7']['additive']=additive_mof_7
results['mof_7']['counter']=counter_ion_mof_7
results['mof_7']['metal']=concentration_metal_mof_7_mol_per_liter
results['mof_7']['linker1']=concentration_first_linker_mof_7_mol_per_liter
results['mof_7']['linker2']=concentration_second_linker_mof_7_mol_per_liter
results['mof_7']['surely']=are_you_sure_about_your_selction_mof_7
results['mof_7']['additional']=what_makes_you_so_sure_or_unsure_mof_7


nutils.print_choice(temperature_mof_7_Celsius, time_mof_7_hours, first_solvent_mof_7,second_solvent_mof_7,third_solvent_mof_7 , counter_ion_mof_7, concentration_metal_mof_7_mol_per_liter, concentration_first_linker_mof_7_mol_per_liter,concentration_second_linker_mof_7_mol_per_liter , additive_mof_7,are_you_sure_about_your_selction_mof_7, what_makes_you_so_sure_or_unsure_mof_7 )


Image('./INOVEN_cleansingle_linker0.png')


nutils.viewer('./INOVEN_clean.cif')


temperature_mof_8_Celsius  = 100.0 #@param {type:'number'}
time_mof_8_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_8 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_8 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_8 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_8 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_8 =  'CL' #@param {type:'string'}
concentration_metal_mof_8_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_8_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_8_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_8 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_8 =  'Found a similar MOF' #@param {type:'string'}
results['mof_8'] = {}
results['mof_8']['temperature']=temperature_mof_8_Celsius
results['mof_8']['time']=time_mof_8_hours
results['mof_8']['solvent1']=first_solvent_mof_8
results['mof_8']['solvent2']=second_solvent_mof_8
results['mof_8']['solvent3']=third_solvent_mof_8
results['mof_8']['additive']=additive_mof_8
results['mof_8']['counter']=counter_ion_mof_8
results['mof_8']['metal']=concentration_metal_mof_8_mol_per_liter
results['mof_8']['linker1']=concentration_first_linker_mof_8_mol_per_liter
results['mof_8']['linker2']=concentration_second_linker_mof_8_mol_per_liter
results['mof_8']['surely']=are_you_sure_about_your_selction_mof_8
results['mof_8']['additional']=what_makes_you_so_sure_or_unsure_mof_8


nutils.print_choice(temperature_mof_8_Celsius, time_mof_8_hours, first_solvent_mof_8,second_solvent_mof_8,third_solvent_mof_8 , counter_ion_mof_8, concentration_metal_mof_8_mol_per_liter, concentration_first_linker_mof_8_mol_per_liter,concentration_second_linker_mof_8_mol_per_liter , additive_mof_8,are_you_sure_about_your_selction_mof_8, what_makes_you_so_sure_or_unsure_mof_8 )


Image('./COVYIX_cleansingle_linker0.png')


Image('./COVYIX_cleansingle_linker1.png')


nutils.viewer('./COVYIX_clean.cif')


temperature_mof_9_Celsius  = 100.0 #@param {type:'number'}
time_mof_9_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_9 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_9 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_9 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_9 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_9 =  'CL' #@param {type:'string'}
concentration_metal_mof_9_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_9_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_9_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_9 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_9 =  'Found a similar MOF' #@param {type:'string'}
results['mof_9'] = {}
results['mof_9']['temperature']=temperature_mof_9_Celsius
results['mof_9']['time']=time_mof_9_hours
results['mof_9']['solvent1']=first_solvent_mof_9
results['mof_9']['solvent2']=second_solvent_mof_9
results['mof_9']['solvent3']=third_solvent_mof_9
results['mof_9']['additive']=additive_mof_9
results['mof_9']['counter']=counter_ion_mof_9
results['mof_9']['metal']=concentration_metal_mof_9_mol_per_liter
results['mof_9']['linker1']=concentration_first_linker_mof_9_mol_per_liter
results['mof_9']['linker2']=concentration_second_linker_mof_9_mol_per_liter
results['mof_9']['surely']=are_you_sure_about_your_selction_mof_9
results['mof_9']['additional']=what_makes_you_so_sure_or_unsure_mof_9


nutils.print_choice(temperature_mof_9_Celsius, time_mof_9_hours, first_solvent_mof_9,second_solvent_mof_9,third_solvent_mof_9 , counter_ion_mof_9, concentration_metal_mof_9_mol_per_liter, concentration_first_linker_mof_9_mol_per_liter,concentration_second_linker_mof_9_mol_per_liter , additive_mof_9,are_you_sure_about_your_selction_mof_9, what_makes_you_so_sure_or_unsure_mof_9 )


Image('./RUFZID_cleansingle_linker0.png')


nutils.viewer('./RUFZID_clean.cif')


temperature_mof_10_Celsius  = 100.0 #@param {type:'number'}
time_mof_10_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_10 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_10 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_10 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_10 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_10 =  'CL' #@param {type:'string'}
concentration_metal_mof_10_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_10_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_10_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_10 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_10 =  'Found a similar MOF' #@param {type:'string'}
results['mof_10'] = {}
results['mof_10']['temperature']=temperature_mof_10_Celsius
results['mof_10']['time']=time_mof_10_hours
results['mof_10']['solvent1']=first_solvent_mof_10
results['mof_10']['solvent2']=second_solvent_mof_10
results['mof_10']['solvent3']=third_solvent_mof_10
results['mof_10']['additive']=additive_mof_10
results['mof_10']['counter']=counter_ion_mof_10
results['mof_10']['metal']=concentration_metal_mof_10_mol_per_liter
results['mof_10']['linker1']=concentration_first_linker_mof_10_mol_per_liter
results['mof_10']['linker2']=concentration_second_linker_mof_10_mol_per_liter
results['mof_10']['surely']=are_you_sure_about_your_selction_mof_10
results['mof_10']['additional']=what_makes_you_so_sure_or_unsure_mof_10


nutils.print_choice(temperature_mof_10_Celsius, time_mof_10_hours, first_solvent_mof_10,second_solvent_mof_10,third_solvent_mof_10 , counter_ion_mof_10, concentration_metal_mof_10_mol_per_liter, concentration_first_linker_mof_10_mol_per_liter,concentration_second_linker_mof_10_mol_per_liter , additive_mof_10,are_you_sure_about_your_selction_mof_10, what_makes_you_so_sure_or_unsure_mof_10 )


Image('./LELROL_cleansingle_linker0.png')


nutils.viewer('./LELROL_clean.cif')


temperature_mof_11_Celsius  = 100.0 #@param {type:'number'}
time_mof_11_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_11 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_11 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_11 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_11 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_11 =  'CL' #@param {type:'string'}
concentration_metal_mof_11_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_11_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_11_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_11 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_11 =  'Found a similar MOF' #@param {type:'string'}
results['mof_11'] = {}
results['mof_11']['temperature']=temperature_mof_11_Celsius
results['mof_11']['time']=time_mof_11_hours
results['mof_11']['solvent1']=first_solvent_mof_11
results['mof_11']['solvent2']=second_solvent_mof_11
results['mof_11']['solvent3']=third_solvent_mof_11
results['mof_11']['additive']=additive_mof_11
results['mof_11']['counter']=counter_ion_mof_11
results['mof_11']['metal']=concentration_metal_mof_11_mol_per_liter
results['mof_11']['linker1']=concentration_first_linker_mof_11_mol_per_liter
results['mof_11']['linker2']=concentration_second_linker_mof_11_mol_per_liter
results['mof_11']['surely']=are_you_sure_about_your_selction_mof_11
results['mof_11']['additional']=what_makes_you_so_sure_or_unsure_mof_11


nutils.print_choice(temperature_mof_11_Celsius, time_mof_11_hours, first_solvent_mof_11,second_solvent_mof_11,third_solvent_mof_11 , counter_ion_mof_11, concentration_metal_mof_11_mol_per_liter, concentration_first_linker_mof_11_mol_per_liter,concentration_second_linker_mof_11_mol_per_liter , additive_mof_11,are_you_sure_about_your_selction_mof_11, what_makes_you_so_sure_or_unsure_mof_11 )


Image('./GAJVIY_chargedsingle_linker0.png')


nutils.viewer('./GAJVIY_charged.cif')


temperature_mof_12_Celsius  = 100.0 #@param {type:'number'}
time_mof_12_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_12 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_12 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_12 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_12 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_12 =  'CL' #@param {type:'string'}
concentration_metal_mof_12_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_12_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_12_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_12 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_12 =  'Found a similar MOF' #@param {type:'string'}
results['mof_12'] = {}
results['mof_12']['temperature']=temperature_mof_12_Celsius
results['mof_12']['time']=time_mof_12_hours
results['mof_12']['solvent1']=first_solvent_mof_12
results['mof_12']['solvent2']=second_solvent_mof_12
results['mof_12']['solvent3']=third_solvent_mof_12
results['mof_12']['additive']=additive_mof_12
results['mof_12']['counter']=counter_ion_mof_12
results['mof_12']['metal']=concentration_metal_mof_12_mol_per_liter
results['mof_12']['linker1']=concentration_first_linker_mof_12_mol_per_liter
results['mof_12']['linker2']=concentration_second_linker_mof_12_mol_per_liter
results['mof_12']['surely']=are_you_sure_about_your_selction_mof_12
results['mof_12']['additional']=what_makes_you_so_sure_or_unsure_mof_12


nutils.print_choice(temperature_mof_12_Celsius, time_mof_12_hours, first_solvent_mof_12,second_solvent_mof_12,third_solvent_mof_12 , counter_ion_mof_12, concentration_metal_mof_12_mol_per_liter, concentration_first_linker_mof_12_mol_per_liter,concentration_second_linker_mof_12_mol_per_liter , additive_mof_12,are_you_sure_about_your_selction_mof_12, what_makes_you_so_sure_or_unsure_mof_12 )


Image('./LENKIA_cleansingle_linker0.png')


nutils.viewer('./LENKIA_clean.cif')


temperature_mof_13_Celsius  = 100.0 #@param {type:'number'}
time_mof_13_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_13 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_13 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_13 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_13 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_13 =  'CL' #@param {type:'string'}
concentration_metal_mof_13_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_13_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_13_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_13 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_13 =  'Found a similar MOF' #@param {type:'string'}
results['mof_13'] = {}
results['mof_13']['temperature']=temperature_mof_13_Celsius
results['mof_13']['time']=time_mof_13_hours
results['mof_13']['solvent1']=first_solvent_mof_13
results['mof_13']['solvent2']=second_solvent_mof_13
results['mof_13']['solvent3']=third_solvent_mof_13
results['mof_13']['additive']=additive_mof_13
results['mof_13']['counter']=counter_ion_mof_13
results['mof_13']['metal']=concentration_metal_mof_13_mol_per_liter
results['mof_13']['linker1']=concentration_first_linker_mof_13_mol_per_liter
results['mof_13']['linker2']=concentration_second_linker_mof_13_mol_per_liter
results['mof_13']['surely']=are_you_sure_about_your_selction_mof_13
results['mof_13']['additional']=what_makes_you_so_sure_or_unsure_mof_13


nutils.print_choice(temperature_mof_13_Celsius, time_mof_13_hours, first_solvent_mof_13,second_solvent_mof_13,third_solvent_mof_13 , counter_ion_mof_13, concentration_metal_mof_13_mol_per_liter, concentration_first_linker_mof_13_mol_per_liter,concentration_second_linker_mof_13_mol_per_liter , additive_mof_13,are_you_sure_about_your_selction_mof_13, what_makes_you_so_sure_or_unsure_mof_13 )


Image('./AVEQID_cleansingle_linker0.png')


nutils.viewer('./AVEQID_clean.cif')


temperature_mof_14_Celsius  = 100.0 #@param {type:'number'}
time_mof_14_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_14 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_14 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_14 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_14 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_14 =  'CL' #@param {type:'string'}
concentration_metal_mof_14_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_14_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_14_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_14 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_14 =  'Found a similar MOF' #@param {type:'string'}
results['mof_14'] = {}
results['mof_14']['temperature']=temperature_mof_14_Celsius
results['mof_14']['time']=time_mof_14_hours
results['mof_14']['solvent1']=first_solvent_mof_14
results['mof_14']['solvent2']=second_solvent_mof_14
results['mof_14']['solvent3']=third_solvent_mof_14
results['mof_14']['additive']=additive_mof_14
results['mof_14']['counter']=counter_ion_mof_14
results['mof_14']['metal']=concentration_metal_mof_14_mol_per_liter
results['mof_14']['linker1']=concentration_first_linker_mof_14_mol_per_liter
results['mof_14']['linker2']=concentration_second_linker_mof_14_mol_per_liter
results['mof_14']['surely']=are_you_sure_about_your_selction_mof_14
results['mof_14']['additional']=what_makes_you_so_sure_or_unsure_mof_14


nutils.print_choice(temperature_mof_14_Celsius, time_mof_14_hours, first_solvent_mof_14,second_solvent_mof_14,third_solvent_mof_14 , counter_ion_mof_14, concentration_metal_mof_14_mol_per_liter, concentration_first_linker_mof_14_mol_per_liter,concentration_second_linker_mof_14_mol_per_liter , additive_mof_14,are_you_sure_about_your_selction_mof_14, what_makes_you_so_sure_or_unsure_mof_14 )


Image('./REYCOP_cleansingle_linker0.png')


Image('./REYCOP_cleansingle_linker2.png')


nutils.viewer('./REYCOP_clean.cif')


temperature_mof_15_Celsius  = 100.0 #@param {type:'number'}
time_mof_15_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_15 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_15 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_15 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_15 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_15 =  'CL' #@param {type:'string'}
concentration_metal_mof_15_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_15_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_15_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_15 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_15 =  'Found a similar MOF' #@param {type:'string'}
results['mof_15'] = {}
results['mof_15']['temperature']=temperature_mof_15_Celsius
results['mof_15']['time']=time_mof_15_hours
results['mof_15']['solvent1']=first_solvent_mof_15
results['mof_15']['solvent2']=second_solvent_mof_15
results['mof_15']['solvent3']=third_solvent_mof_15
results['mof_15']['additive']=additive_mof_15
results['mof_15']['counter']=counter_ion_mof_15
results['mof_15']['metal']=concentration_metal_mof_15_mol_per_liter
results['mof_15']['linker1']=concentration_first_linker_mof_15_mol_per_liter
results['mof_15']['linker2']=concentration_second_linker_mof_15_mol_per_liter
results['mof_15']['surely']=are_you_sure_about_your_selction_mof_15
results['mof_15']['additional']=what_makes_you_so_sure_or_unsure_mof_15


nutils.print_choice(temperature_mof_15_Celsius, time_mof_15_hours, first_solvent_mof_15,second_solvent_mof_15,third_solvent_mof_15 , counter_ion_mof_15, concentration_metal_mof_15_mol_per_liter, concentration_first_linker_mof_15_mol_per_liter,concentration_second_linker_mof_15_mol_per_liter , additive_mof_15,are_you_sure_about_your_selction_mof_15, what_makes_you_so_sure_or_unsure_mof_15 )


Image('./EVADIQ_cleansingle_linker0.png')


nutils.viewer('./EVADIQ_clean.cif')


temperature_mof_16_Celsius  = 100.0 #@param {type:'number'}
time_mof_16_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_16 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_16 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_16 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_16 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_16 =  'CL' #@param {type:'string'}
concentration_metal_mof_16_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_16_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_16_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_16 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_16 =  'Found a similar MOF' #@param {type:'string'}
results['mof_16'] = {}
results['mof_16']['temperature']=temperature_mof_16_Celsius
results['mof_16']['time']=time_mof_16_hours
results['mof_16']['solvent1']=first_solvent_mof_16
results['mof_16']['solvent2']=second_solvent_mof_16
results['mof_16']['solvent3']=third_solvent_mof_16
results['mof_16']['additive']=additive_mof_16
results['mof_16']['counter']=counter_ion_mof_16
results['mof_16']['metal']=concentration_metal_mof_16_mol_per_liter
results['mof_16']['linker1']=concentration_first_linker_mof_16_mol_per_liter
results['mof_16']['linker2']=concentration_second_linker_mof_16_mol_per_liter
results['mof_16']['surely']=are_you_sure_about_your_selction_mof_16
results['mof_16']['additional']=what_makes_you_so_sure_or_unsure_mof_16


nutils.print_choice(temperature_mof_16_Celsius, time_mof_16_hours, first_solvent_mof_16,second_solvent_mof_16,third_solvent_mof_16 , counter_ion_mof_16, concentration_metal_mof_16_mol_per_liter, concentration_first_linker_mof_16_mol_per_liter,concentration_second_linker_mof_16_mol_per_liter , additive_mof_16,are_you_sure_about_your_selction_mof_16, what_makes_you_so_sure_or_unsure_mof_16 )


Image('./AXOHIE_cleansingle_linker0.png')


Image('./AXOHIE_cleansingle_linker3.png')


nutils.viewer('./AXOHIE_clean.cif')


temperature_mof_17_Celsius  = 100.0 #@param {type:'number'}
time_mof_17_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_17 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_17 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_17 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_17 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_17 =  'CL' #@param {type:'string'}
concentration_metal_mof_17_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_17_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_17_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_17 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_17 =  'Found a similar MOF' #@param {type:'string'}
results['mof_17'] = {}
results['mof_17']['temperature']=temperature_mof_17_Celsius
results['mof_17']['time']=time_mof_17_hours
results['mof_17']['solvent1']=first_solvent_mof_17
results['mof_17']['solvent2']=second_solvent_mof_17
results['mof_17']['solvent3']=third_solvent_mof_17
results['mof_17']['additive']=additive_mof_17
results['mof_17']['counter']=counter_ion_mof_17
results['mof_17']['metal']=concentration_metal_mof_17_mol_per_liter
results['mof_17']['linker1']=concentration_first_linker_mof_17_mol_per_liter
results['mof_17']['linker2']=concentration_second_linker_mof_17_mol_per_liter
results['mof_17']['surely']=are_you_sure_about_your_selction_mof_17
results['mof_17']['additional']=what_makes_you_so_sure_or_unsure_mof_17


nutils.print_choice(temperature_mof_17_Celsius, time_mof_17_hours, first_solvent_mof_17,second_solvent_mof_17,third_solvent_mof_17 , counter_ion_mof_17, concentration_metal_mof_17_mol_per_liter, concentration_first_linker_mof_17_mol_per_liter,concentration_second_linker_mof_17_mol_per_liter , additive_mof_17,are_you_sure_about_your_selction_mof_17, what_makes_you_so_sure_or_unsure_mof_17 )


Image('./OFODET_cleansingle_linker0.png')


nutils.viewer('./OFODET_clean.cif')


temperature_mof_18_Celsius  = 100.0 #@param {type:'number'}
time_mof_18_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_18 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_18 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_18 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_18 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_18 =  'CL' #@param {type:'string'}
concentration_metal_mof_18_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_18_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_18_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_18 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_18 =  'Found a similar MOF' #@param {type:'string'}
results['mof_18'] = {}
results['mof_18']['temperature']=temperature_mof_18_Celsius
results['mof_18']['time']=time_mof_18_hours
results['mof_18']['solvent1']=first_solvent_mof_18
results['mof_18']['solvent2']=second_solvent_mof_18
results['mof_18']['solvent3']=third_solvent_mof_18
results['mof_18']['additive']=additive_mof_18
results['mof_18']['counter']=counter_ion_mof_18
results['mof_18']['metal']=concentration_metal_mof_18_mol_per_liter
results['mof_18']['linker1']=concentration_first_linker_mof_18_mol_per_liter
results['mof_18']['linker2']=concentration_second_linker_mof_18_mol_per_liter
results['mof_18']['surely']=are_you_sure_about_your_selction_mof_18
results['mof_18']['additional']=what_makes_you_so_sure_or_unsure_mof_18


nutils.print_choice(temperature_mof_18_Celsius, time_mof_18_hours, first_solvent_mof_18,second_solvent_mof_18,third_solvent_mof_18 , counter_ion_mof_18, concentration_metal_mof_18_mol_per_liter, concentration_first_linker_mof_18_mol_per_liter,concentration_second_linker_mof_18_mol_per_liter , additive_mof_18,are_you_sure_about_your_selction_mof_18, what_makes_you_so_sure_or_unsure_mof_18 )


Image('./TEMPAE_cleansingle_linker0.png')


nutils.viewer('./TEMPAE_clean.cif')


temperature_mof_19_Celsius  = 100.0 #@param {type:'number'}
time_mof_19_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_19 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_19 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_19 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_19 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_19 =  'CL' #@param {type:'string'}
concentration_metal_mof_19_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_19_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_19_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_19 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_19 =  'Found a similar MOF' #@param {type:'string'}
results['mof_19'] = {}
results['mof_19']['temperature']=temperature_mof_19_Celsius
results['mof_19']['time']=time_mof_19_hours
results['mof_19']['solvent1']=first_solvent_mof_19
results['mof_19']['solvent2']=second_solvent_mof_19
results['mof_19']['solvent3']=third_solvent_mof_19
results['mof_19']['additive']=additive_mof_19
results['mof_19']['counter']=counter_ion_mof_19
results['mof_19']['metal']=concentration_metal_mof_19_mol_per_liter
results['mof_19']['linker1']=concentration_first_linker_mof_19_mol_per_liter
results['mof_19']['linker2']=concentration_second_linker_mof_19_mol_per_liter
results['mof_19']['surely']=are_you_sure_about_your_selction_mof_19
results['mof_19']['additional']=what_makes_you_so_sure_or_unsure_mof_19


nutils.print_choice(temperature_mof_19_Celsius, time_mof_19_hours, first_solvent_mof_19,second_solvent_mof_19,third_solvent_mof_19 , counter_ion_mof_19, concentration_metal_mof_19_mol_per_liter, concentration_first_linker_mof_19_mol_per_liter,concentration_second_linker_mof_19_mol_per_liter , additive_mof_19,are_you_sure_about_your_selction_mof_19, what_makes_you_so_sure_or_unsure_mof_19 )


Image('./WIPLOY_cleansingle_linker0.png')


nutils.viewer('./WIPLOY_clean.cif')


temperature_mof_20_Celsius  = 100.0 #@param {type:'number'}
time_mof_20_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_20 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_20 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_20 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_20 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_20 =  'CL' #@param {type:'string'}
concentration_metal_mof_20_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_20_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_20_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_20 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_20 =  'Found a similar MOF' #@param {type:'string'}
results['mof_20'] = {}
results['mof_20']['temperature']=temperature_mof_20_Celsius
results['mof_20']['time']=time_mof_20_hours
results['mof_20']['solvent1']=first_solvent_mof_20
results['mof_20']['solvent2']=second_solvent_mof_20
results['mof_20']['solvent3']=third_solvent_mof_20
results['mof_20']['additive']=additive_mof_20
results['mof_20']['counter']=counter_ion_mof_20
results['mof_20']['metal']=concentration_metal_mof_20_mol_per_liter
results['mof_20']['linker1']=concentration_first_linker_mof_20_mol_per_liter
results['mof_20']['linker2']=concentration_second_linker_mof_20_mol_per_liter
results['mof_20']['surely']=are_you_sure_about_your_selction_mof_20
results['mof_20']['additional']=what_makes_you_so_sure_or_unsure_mof_20


nutils.print_choice(temperature_mof_20_Celsius, time_mof_20_hours, first_solvent_mof_20,second_solvent_mof_20,third_solvent_mof_20 , counter_ion_mof_20, concentration_metal_mof_20_mol_per_liter, concentration_first_linker_mof_20_mol_per_liter,concentration_second_linker_mof_20_mol_per_liter , additive_mof_20,are_you_sure_about_your_selction_mof_20, what_makes_you_so_sure_or_unsure_mof_20 )


Image('./NUBPIL_cleansingle_linker0.png')


nutils.viewer('./NUBPIL_clean.cif')


temperature_mof_21_Celsius  = 100.0 #@param {type:'number'}
time_mof_21_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_21 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_21 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_21 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_21 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_21 =  'CL' #@param {type:'string'}
concentration_metal_mof_21_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_21_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_21_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_21 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_21 =  'Found a similar MOF' #@param {type:'string'}
results['mof_21'] = {}
results['mof_21']['temperature']=temperature_mof_21_Celsius
results['mof_21']['time']=time_mof_21_hours
results['mof_21']['solvent1']=first_solvent_mof_21
results['mof_21']['solvent2']=second_solvent_mof_21
results['mof_21']['solvent3']=third_solvent_mof_21
results['mof_21']['additive']=additive_mof_21
results['mof_21']['counter']=counter_ion_mof_21
results['mof_21']['metal']=concentration_metal_mof_21_mol_per_liter
results['mof_21']['linker1']=concentration_first_linker_mof_21_mol_per_liter
results['mof_21']['linker2']=concentration_second_linker_mof_21_mol_per_liter
results['mof_21']['surely']=are_you_sure_about_your_selction_mof_21
results['mof_21']['additional']=what_makes_you_so_sure_or_unsure_mof_21


nutils.print_choice(temperature_mof_21_Celsius, time_mof_21_hours, first_solvent_mof_21,second_solvent_mof_21,third_solvent_mof_21 , counter_ion_mof_21, concentration_metal_mof_21_mol_per_liter, concentration_first_linker_mof_21_mol_per_liter,concentration_second_linker_mof_21_mol_per_liter , additive_mof_21,are_you_sure_about_your_selction_mof_21, what_makes_you_so_sure_or_unsure_mof_21 )


Image('./PEKZIP_cleansingle_linker0.png')


nutils.viewer('./PEKZIP_clean.cif')


temperature_mof_22_Celsius  = 100.0 #@param {type:'number'}
time_mof_22_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_22 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_22 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_22 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_22 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_22 =  'CL' #@param {type:'string'}
concentration_metal_mof_22_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_22_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_22_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_22 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_22 =  'Found a similar MOF' #@param {type:'string'}
results['mof_22'] = {}
results['mof_22']['temperature']=temperature_mof_22_Celsius
results['mof_22']['time']=time_mof_22_hours
results['mof_22']['solvent1']=first_solvent_mof_22
results['mof_22']['solvent2']=second_solvent_mof_22
results['mof_22']['solvent3']=third_solvent_mof_22
results['mof_22']['additive']=additive_mof_22
results['mof_22']['counter']=counter_ion_mof_22
results['mof_22']['metal']=concentration_metal_mof_22_mol_per_liter
results['mof_22']['linker1']=concentration_first_linker_mof_22_mol_per_liter
results['mof_22']['linker2']=concentration_second_linker_mof_22_mol_per_liter
results['mof_22']['surely']=are_you_sure_about_your_selction_mof_22
results['mof_22']['additional']=what_makes_you_so_sure_or_unsure_mof_22


nutils.print_choice(temperature_mof_22_Celsius, time_mof_22_hours, first_solvent_mof_22,second_solvent_mof_22,third_solvent_mof_22 , counter_ion_mof_22, concentration_metal_mof_22_mol_per_liter, concentration_first_linker_mof_22_mol_per_liter,concentration_second_linker_mof_22_mol_per_liter , additive_mof_22,are_you_sure_about_your_selction_mof_22, what_makes_you_so_sure_or_unsure_mof_22 )


Image('./FIMXUW_cleansingle_linker2.png')


nutils.viewer('./FIMXUW_clean.cif')


temperature_mof_23_Celsius  = 100.0 #@param {type:'number'}
time_mof_23_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_23 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_23 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_23 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_23 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_23 =  'CL' #@param {type:'string'}
concentration_metal_mof_23_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_23_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_23_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_23 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_23 =  'Found a similar MOF' #@param {type:'string'}
results['mof_23'] = {}
results['mof_23']['temperature']=temperature_mof_23_Celsius
results['mof_23']['time']=time_mof_23_hours
results['mof_23']['solvent1']=first_solvent_mof_23
results['mof_23']['solvent2']=second_solvent_mof_23
results['mof_23']['solvent3']=third_solvent_mof_23
results['mof_23']['additive']=additive_mof_23
results['mof_23']['counter']=counter_ion_mof_23
results['mof_23']['metal']=concentration_metal_mof_23_mol_per_liter
results['mof_23']['linker1']=concentration_first_linker_mof_23_mol_per_liter
results['mof_23']['linker2']=concentration_second_linker_mof_23_mol_per_liter
results['mof_23']['surely']=are_you_sure_about_your_selction_mof_23
results['mof_23']['additional']=what_makes_you_so_sure_or_unsure_mof_23


nutils.print_choice(temperature_mof_23_Celsius, time_mof_23_hours, first_solvent_mof_23,second_solvent_mof_23,third_solvent_mof_23 , counter_ion_mof_23, concentration_metal_mof_23_mol_per_liter, concentration_first_linker_mof_23_mol_per_liter,concentration_second_linker_mof_23_mol_per_liter , additive_mof_23,are_you_sure_about_your_selction_mof_23, what_makes_you_so_sure_or_unsure_mof_23 )


Image('./REYCEF_cleansingle_linker0.png')


Image('./REYCEF_cleansingle_linker2.png')


nutils.viewer('./REYCEF_clean.cif')


temperature_mof_24_Celsius  = 100.0 #@param {type:'number'}
time_mof_24_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_24 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_24 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_24 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_24 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_24 =  'CL' #@param {type:'string'}
concentration_metal_mof_24_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_24_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_24_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_24 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_24 =  'Found a similar MOF' #@param {type:'string'}
results['mof_24'] = {}
results['mof_24']['temperature']=temperature_mof_24_Celsius
results['mof_24']['time']=time_mof_24_hours
results['mof_24']['solvent1']=first_solvent_mof_24
results['mof_24']['solvent2']=second_solvent_mof_24
results['mof_24']['solvent3']=third_solvent_mof_24
results['mof_24']['additive']=additive_mof_24
results['mof_24']['counter']=counter_ion_mof_24
results['mof_24']['metal']=concentration_metal_mof_24_mol_per_liter
results['mof_24']['linker1']=concentration_first_linker_mof_24_mol_per_liter
results['mof_24']['linker2']=concentration_second_linker_mof_24_mol_per_liter
results['mof_24']['surely']=are_you_sure_about_your_selction_mof_24
results['mof_24']['additional']=what_makes_you_so_sure_or_unsure_mof_24


nutils.print_choice(temperature_mof_24_Celsius, time_mof_24_hours, first_solvent_mof_24,second_solvent_mof_24,third_solvent_mof_24 , counter_ion_mof_24, concentration_metal_mof_24_mol_per_liter, concentration_first_linker_mof_24_mol_per_liter,concentration_second_linker_mof_24_mol_per_liter , additive_mof_24,are_you_sure_about_your_selction_mof_24, what_makes_you_so_sure_or_unsure_mof_24 )


Image('./IZEWAN_cleansingle_linker0.png')


nutils.viewer('./IZEWAN_clean.cif')


temperature_mof_25_Celsius  = 100.0 #@param {type:'number'}
time_mof_25_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_25 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_25 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_25 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_25 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_25 =  'CL' #@param {type:'string'}
concentration_metal_mof_25_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_25_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_25_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_25 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_25 =  'Found a similar MOF' #@param {type:'string'}
results['mof_25'] = {}
results['mof_25']['temperature']=temperature_mof_25_Celsius
results['mof_25']['time']=time_mof_25_hours
results['mof_25']['solvent1']=first_solvent_mof_25
results['mof_25']['solvent2']=second_solvent_mof_25
results['mof_25']['solvent3']=third_solvent_mof_25
results['mof_25']['additive']=additive_mof_25
results['mof_25']['counter']=counter_ion_mof_25
results['mof_25']['metal']=concentration_metal_mof_25_mol_per_liter
results['mof_25']['linker1']=concentration_first_linker_mof_25_mol_per_liter
results['mof_25']['linker2']=concentration_second_linker_mof_25_mol_per_liter
results['mof_25']['surely']=are_you_sure_about_your_selction_mof_25
results['mof_25']['additional']=what_makes_you_so_sure_or_unsure_mof_25


nutils.print_choice(temperature_mof_25_Celsius, time_mof_25_hours, first_solvent_mof_25,second_solvent_mof_25,third_solvent_mof_25 , counter_ion_mof_25, concentration_metal_mof_25_mol_per_liter, concentration_first_linker_mof_25_mol_per_liter,concentration_second_linker_mof_25_mol_per_liter , additive_mof_25,are_you_sure_about_your_selction_mof_25, what_makes_you_so_sure_or_unsure_mof_25 )


Image('./WEGDIX_chargedsingle_linker0.png')


nutils.viewer('./WEGDIX_charged.cif')


temperature_mof_26_Celsius  = 100.0 #@param {type:'number'}
time_mof_26_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_26 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_26 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_26 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_26 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_26 =  'CL' #@param {type:'string'}
concentration_metal_mof_26_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_26_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_26_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_26 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_26 =  'Found a similar MOF' #@param {type:'string'}
results['mof_26'] = {}
results['mof_26']['temperature']=temperature_mof_26_Celsius
results['mof_26']['time']=time_mof_26_hours
results['mof_26']['solvent1']=first_solvent_mof_26
results['mof_26']['solvent2']=second_solvent_mof_26
results['mof_26']['solvent3']=third_solvent_mof_26
results['mof_26']['additive']=additive_mof_26
results['mof_26']['counter']=counter_ion_mof_26
results['mof_26']['metal']=concentration_metal_mof_26_mol_per_liter
results['mof_26']['linker1']=concentration_first_linker_mof_26_mol_per_liter
results['mof_26']['linker2']=concentration_second_linker_mof_26_mol_per_liter
results['mof_26']['surely']=are_you_sure_about_your_selction_mof_26
results['mof_26']['additional']=what_makes_you_so_sure_or_unsure_mof_26


nutils.print_choice(temperature_mof_26_Celsius, time_mof_26_hours, first_solvent_mof_26,second_solvent_mof_26,third_solvent_mof_26 , counter_ion_mof_26, concentration_metal_mof_26_mol_per_liter, concentration_first_linker_mof_26_mol_per_liter,concentration_second_linker_mof_26_mol_per_liter , additive_mof_26,are_you_sure_about_your_selction_mof_26, what_makes_you_so_sure_or_unsure_mof_26 )


Image('./CABQEB_cleansingle_linker0.png')


nutils.viewer('./CABQEB_clean.cif')


temperature_mof_27_Celsius  = 100.0 #@param {type:'number'}
time_mof_27_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_27 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_27 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_27 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_27 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_27 =  'CL' #@param {type:'string'}
concentration_metal_mof_27_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_27_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_27_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_27 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_27 =  'Found a similar MOF' #@param {type:'string'}
results['mof_27'] = {}
results['mof_27']['temperature']=temperature_mof_27_Celsius
results['mof_27']['time']=time_mof_27_hours
results['mof_27']['solvent1']=first_solvent_mof_27
results['mof_27']['solvent2']=second_solvent_mof_27
results['mof_27']['solvent3']=third_solvent_mof_27
results['mof_27']['additive']=additive_mof_27
results['mof_27']['counter']=counter_ion_mof_27
results['mof_27']['metal']=concentration_metal_mof_27_mol_per_liter
results['mof_27']['linker1']=concentration_first_linker_mof_27_mol_per_liter
results['mof_27']['linker2']=concentration_second_linker_mof_27_mol_per_liter
results['mof_27']['surely']=are_you_sure_about_your_selction_mof_27
results['mof_27']['additional']=what_makes_you_so_sure_or_unsure_mof_27


nutils.print_choice(temperature_mof_27_Celsius, time_mof_27_hours, first_solvent_mof_27,second_solvent_mof_27,third_solvent_mof_27 , counter_ion_mof_27, concentration_metal_mof_27_mol_per_liter, concentration_first_linker_mof_27_mol_per_liter,concentration_second_linker_mof_27_mol_per_liter , additive_mof_27,are_you_sure_about_your_selction_mof_27, what_makes_you_so_sure_or_unsure_mof_27 )


Image('./BINSAU_cleansingle_linker0.png')


nutils.viewer('./BINSAU_clean.cif')


temperature_mof_28_Celsius  = 100.0 #@param {type:'number'}
time_mof_28_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_28 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_28 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_28 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_28 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_28 =  'CL' #@param {type:'string'}
concentration_metal_mof_28_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_28_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_28_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_28 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_28 =  'Found a similar MOF' #@param {type:'string'}
results['mof_28'] = {}
results['mof_28']['temperature']=temperature_mof_28_Celsius
results['mof_28']['time']=time_mof_28_hours
results['mof_28']['solvent1']=first_solvent_mof_28
results['mof_28']['solvent2']=second_solvent_mof_28
results['mof_28']['solvent3']=third_solvent_mof_28
results['mof_28']['additive']=additive_mof_28
results['mof_28']['counter']=counter_ion_mof_28
results['mof_28']['metal']=concentration_metal_mof_28_mol_per_liter
results['mof_28']['linker1']=concentration_first_linker_mof_28_mol_per_liter
results['mof_28']['linker2']=concentration_second_linker_mof_28_mol_per_liter
results['mof_28']['surely']=are_you_sure_about_your_selction_mof_28
results['mof_28']['additional']=what_makes_you_so_sure_or_unsure_mof_28


nutils.print_choice(temperature_mof_28_Celsius, time_mof_28_hours, first_solvent_mof_28,second_solvent_mof_28,third_solvent_mof_28 , counter_ion_mof_28, concentration_metal_mof_28_mol_per_liter, concentration_first_linker_mof_28_mol_per_liter,concentration_second_linker_mof_28_mol_per_liter , additive_mof_28,are_you_sure_about_your_selction_mof_28, what_makes_you_so_sure_or_unsure_mof_28 )


Image('./EBUREA_cleansingle_linker0.png')


nutils.viewer('./EBUREA_clean.cif')


temperature_mof_29_Celsius  = 100.0 #@param {type:'number'}
time_mof_29_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_29 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_29 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_29 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_29 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_29 =  'CL' #@param {type:'string'}
concentration_metal_mof_29_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_29_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_29_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_29 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_29 =  'Found a similar MOF' #@param {type:'string'}
results['mof_29'] = {}
results['mof_29']['temperature']=temperature_mof_29_Celsius
results['mof_29']['time']=time_mof_29_hours
results['mof_29']['solvent1']=first_solvent_mof_29
results['mof_29']['solvent2']=second_solvent_mof_29
results['mof_29']['solvent3']=third_solvent_mof_29
results['mof_29']['additive']=additive_mof_29
results['mof_29']['counter']=counter_ion_mof_29
results['mof_29']['metal']=concentration_metal_mof_29_mol_per_liter
results['mof_29']['linker1']=concentration_first_linker_mof_29_mol_per_liter
results['mof_29']['linker2']=concentration_second_linker_mof_29_mol_per_liter
results['mof_29']['surely']=are_you_sure_about_your_selction_mof_29
results['mof_29']['additional']=what_makes_you_so_sure_or_unsure_mof_29


nutils.print_choice(temperature_mof_29_Celsius, time_mof_29_hours, first_solvent_mof_29,second_solvent_mof_29,third_solvent_mof_29 , counter_ion_mof_29, concentration_metal_mof_29_mol_per_liter, concentration_first_linker_mof_29_mol_per_liter,concentration_second_linker_mof_29_mol_per_liter , additive_mof_29,are_you_sure_about_your_selction_mof_29, what_makes_you_so_sure_or_unsure_mof_29 )


Image('./LOXBEH_cleansingle_linker0.png')


Image('./LOXBEH_cleansingle_linker2.png')


nutils.viewer('./LOXBEH_clean.cif')


temperature_mof_30_Celsius  = 100.0 #@param {type:'number'}
time_mof_30_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_30 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_30 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_30 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_30 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_30 =  'CL' #@param {type:'string'}
concentration_metal_mof_30_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_30_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_30_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_30 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_30 =  'Found a similar MOF' #@param {type:'string'}
results['mof_30'] = {}
results['mof_30']['temperature']=temperature_mof_30_Celsius
results['mof_30']['time']=time_mof_30_hours
results['mof_30']['solvent1']=first_solvent_mof_30
results['mof_30']['solvent2']=second_solvent_mof_30
results['mof_30']['solvent3']=third_solvent_mof_30
results['mof_30']['additive']=additive_mof_30
results['mof_30']['counter']=counter_ion_mof_30
results['mof_30']['metal']=concentration_metal_mof_30_mol_per_liter
results['mof_30']['linker1']=concentration_first_linker_mof_30_mol_per_liter
results['mof_30']['linker2']=concentration_second_linker_mof_30_mol_per_liter
results['mof_30']['surely']=are_you_sure_about_your_selction_mof_30
results['mof_30']['additional']=what_makes_you_so_sure_or_unsure_mof_30


nutils.print_choice(temperature_mof_30_Celsius, time_mof_30_hours, first_solvent_mof_30,second_solvent_mof_30,third_solvent_mof_30 , counter_ion_mof_30, concentration_metal_mof_30_mol_per_liter, concentration_first_linker_mof_30_mol_per_liter,concentration_second_linker_mof_30_mol_per_liter , additive_mof_30,are_you_sure_about_your_selction_mof_30, what_makes_you_so_sure_or_unsure_mof_30 )


Image('./ZUDQEW_cleansingle_linker0.png')


nutils.viewer('./ZUDQEW_clean.cif')


temperature_mof_31_Celsius  = 100.0 #@param {type:'number'}
time_mof_31_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_31 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_31 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_31 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_31 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_31 =  'CL' #@param {type:'string'}
concentration_metal_mof_31_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_31_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_31_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_31 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_31 =  'Found a similar MOF' #@param {type:'string'}
results['mof_31'] = {}
results['mof_31']['temperature']=temperature_mof_31_Celsius
results['mof_31']['time']=time_mof_31_hours
results['mof_31']['solvent1']=first_solvent_mof_31
results['mof_31']['solvent2']=second_solvent_mof_31
results['mof_31']['solvent3']=third_solvent_mof_31
results['mof_31']['additive']=additive_mof_31
results['mof_31']['counter']=counter_ion_mof_31
results['mof_31']['metal']=concentration_metal_mof_31_mol_per_liter
results['mof_31']['linker1']=concentration_first_linker_mof_31_mol_per_liter
results['mof_31']['linker2']=concentration_second_linker_mof_31_mol_per_liter
results['mof_31']['surely']=are_you_sure_about_your_selction_mof_31
results['mof_31']['additional']=what_makes_you_so_sure_or_unsure_mof_31


nutils.print_choice(temperature_mof_31_Celsius, time_mof_31_hours, first_solvent_mof_31,second_solvent_mof_31,third_solvent_mof_31 , counter_ion_mof_31, concentration_metal_mof_31_mol_per_liter, concentration_first_linker_mof_31_mol_per_liter,concentration_second_linker_mof_31_mol_per_liter , additive_mof_31,are_you_sure_about_your_selction_mof_31, what_makes_you_so_sure_or_unsure_mof_31 )


Image('./TOFLAD_cleansingle_linker0.png')


Image('./TOFLAD_cleansingle_linker1.png')


nutils.viewer('./TOFLAD_clean.cif')


temperature_mof_32_Celsius  = 100.0 #@param {type:'number'}
time_mof_32_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_32 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_32 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_32 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_32 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_32 =  'CL' #@param {type:'string'}
concentration_metal_mof_32_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_32_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_32_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_32 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_32 =  'Found a similar MOF' #@param {type:'string'}
results['mof_32'] = {}
results['mof_32']['temperature']=temperature_mof_32_Celsius
results['mof_32']['time']=time_mof_32_hours
results['mof_32']['solvent1']=first_solvent_mof_32
results['mof_32']['solvent2']=second_solvent_mof_32
results['mof_32']['solvent3']=third_solvent_mof_32
results['mof_32']['additive']=additive_mof_32
results['mof_32']['counter']=counter_ion_mof_32
results['mof_32']['metal']=concentration_metal_mof_32_mol_per_liter
results['mof_32']['linker1']=concentration_first_linker_mof_32_mol_per_liter
results['mof_32']['linker2']=concentration_second_linker_mof_32_mol_per_liter
results['mof_32']['surely']=are_you_sure_about_your_selction_mof_32
results['mof_32']['additional']=what_makes_you_so_sure_or_unsure_mof_32


nutils.print_choice(temperature_mof_32_Celsius, time_mof_32_hours, first_solvent_mof_32,second_solvent_mof_32,third_solvent_mof_32 , counter_ion_mof_32, concentration_metal_mof_32_mol_per_liter, concentration_first_linker_mof_32_mol_per_liter,concentration_second_linker_mof_32_mol_per_liter , additive_mof_32,are_you_sure_about_your_selction_mof_32, what_makes_you_so_sure_or_unsure_mof_32 )


Image('./TEJBAN_cleansingle_linker0.png')


nutils.viewer('./TEJBAN_clean.cif')


temperature_mof_33_Celsius  = 100.0 #@param {type:'number'}
time_mof_33_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_33 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_33 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_33 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_33 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_33 =  'CL' #@param {type:'string'}
concentration_metal_mof_33_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_33_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_33_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_33 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_33 =  'Found a similar MOF' #@param {type:'string'}
results['mof_33'] = {}
results['mof_33']['temperature']=temperature_mof_33_Celsius
results['mof_33']['time']=time_mof_33_hours
results['mof_33']['solvent1']=first_solvent_mof_33
results['mof_33']['solvent2']=second_solvent_mof_33
results['mof_33']['solvent3']=third_solvent_mof_33
results['mof_33']['additive']=additive_mof_33
results['mof_33']['counter']=counter_ion_mof_33
results['mof_33']['metal']=concentration_metal_mof_33_mol_per_liter
results['mof_33']['linker1']=concentration_first_linker_mof_33_mol_per_liter
results['mof_33']['linker2']=concentration_second_linker_mof_33_mol_per_liter
results['mof_33']['surely']=are_you_sure_about_your_selction_mof_33
results['mof_33']['additional']=what_makes_you_so_sure_or_unsure_mof_33


nutils.print_choice(temperature_mof_33_Celsius, time_mof_33_hours, first_solvent_mof_33,second_solvent_mof_33,third_solvent_mof_33 , counter_ion_mof_33, concentration_metal_mof_33_mol_per_liter, concentration_first_linker_mof_33_mol_per_liter,concentration_second_linker_mof_33_mol_per_liter , additive_mof_33,are_you_sure_about_your_selction_mof_33, what_makes_you_so_sure_or_unsure_mof_33 )


Image('./DEPXAY_cleansingle_linker0.png')


nutils.viewer('./DEPXAY_clean.cif')


temperature_mof_34_Celsius  = 100.0 #@param {type:'number'}
time_mof_34_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_34 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_34 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_34 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_34 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_34 =  'CL' #@param {type:'string'}
concentration_metal_mof_34_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_34_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_34_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_34 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_34 =  'Found a similar MOF' #@param {type:'string'}
results['mof_34'] = {}
results['mof_34']['temperature']=temperature_mof_34_Celsius
results['mof_34']['time']=time_mof_34_hours
results['mof_34']['solvent1']=first_solvent_mof_34
results['mof_34']['solvent2']=second_solvent_mof_34
results['mof_34']['solvent3']=third_solvent_mof_34
results['mof_34']['additive']=additive_mof_34
results['mof_34']['counter']=counter_ion_mof_34
results['mof_34']['metal']=concentration_metal_mof_34_mol_per_liter
results['mof_34']['linker1']=concentration_first_linker_mof_34_mol_per_liter
results['mof_34']['linker2']=concentration_second_linker_mof_34_mol_per_liter
results['mof_34']['surely']=are_you_sure_about_your_selction_mof_34
results['mof_34']['additional']=what_makes_you_so_sure_or_unsure_mof_34


nutils.print_choice(temperature_mof_34_Celsius, time_mof_34_hours, first_solvent_mof_34,second_solvent_mof_34,third_solvent_mof_34 , counter_ion_mof_34, concentration_metal_mof_34_mol_per_liter, concentration_first_linker_mof_34_mol_per_liter,concentration_second_linker_mof_34_mol_per_liter , additive_mof_34,are_you_sure_about_your_selction_mof_34, what_makes_you_so_sure_or_unsure_mof_34 )


Image('./TETZID_cleansingle_linker0.png')


Image('./TETZID_cleansingle_linker2.png')


nutils.viewer('./TETZID_clean.cif')


temperature_mof_35_Celsius  = 100.0 #@param {type:'number'}
time_mof_35_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_35 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_35 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_35 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_35 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_35 =  'CL' #@param {type:'string'}
concentration_metal_mof_35_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_35_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_35_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_35 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_35 =  'Found a similar MOF' #@param {type:'string'}
results['mof_35'] = {}
results['mof_35']['temperature']=temperature_mof_35_Celsius
results['mof_35']['time']=time_mof_35_hours
results['mof_35']['solvent1']=first_solvent_mof_35
results['mof_35']['solvent2']=second_solvent_mof_35
results['mof_35']['solvent3']=third_solvent_mof_35
results['mof_35']['additive']=additive_mof_35
results['mof_35']['counter']=counter_ion_mof_35
results['mof_35']['metal']=concentration_metal_mof_35_mol_per_liter
results['mof_35']['linker1']=concentration_first_linker_mof_35_mol_per_liter
results['mof_35']['linker2']=concentration_second_linker_mof_35_mol_per_liter
results['mof_35']['surely']=are_you_sure_about_your_selction_mof_35
results['mof_35']['additional']=what_makes_you_so_sure_or_unsure_mof_35


nutils.print_choice(temperature_mof_35_Celsius, time_mof_35_hours, first_solvent_mof_35,second_solvent_mof_35,third_solvent_mof_35 , counter_ion_mof_35, concentration_metal_mof_35_mol_per_liter, concentration_first_linker_mof_35_mol_per_liter,concentration_second_linker_mof_35_mol_per_liter , additive_mof_35,are_you_sure_about_your_selction_mof_35, what_makes_you_so_sure_or_unsure_mof_35 )


Image('./VIZQEC_cleansingle_linker0.png')


nutils.viewer('./VIZQEC_clean.cif')


temperature_mof_36_Celsius  = 100.0 #@param {type:'number'}
time_mof_36_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_36 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_36 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_36 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_36 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_36 =  'CL' #@param {type:'string'}
concentration_metal_mof_36_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_36_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_36_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_36 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_36 =  'Found a similar MOF' #@param {type:'string'}
results['mof_36'] = {}
results['mof_36']['temperature']=temperature_mof_36_Celsius
results['mof_36']['time']=time_mof_36_hours
results['mof_36']['solvent1']=first_solvent_mof_36
results['mof_36']['solvent2']=second_solvent_mof_36
results['mof_36']['solvent3']=third_solvent_mof_36
results['mof_36']['additive']=additive_mof_36
results['mof_36']['counter']=counter_ion_mof_36
results['mof_36']['metal']=concentration_metal_mof_36_mol_per_liter
results['mof_36']['linker1']=concentration_first_linker_mof_36_mol_per_liter
results['mof_36']['linker2']=concentration_second_linker_mof_36_mol_per_liter
results['mof_36']['surely']=are_you_sure_about_your_selction_mof_36
results['mof_36']['additional']=what_makes_you_so_sure_or_unsure_mof_36


nutils.print_choice(temperature_mof_36_Celsius, time_mof_36_hours, first_solvent_mof_36,second_solvent_mof_36,third_solvent_mof_36 , counter_ion_mof_36, concentration_metal_mof_36_mol_per_liter, concentration_first_linker_mof_36_mol_per_liter,concentration_second_linker_mof_36_mol_per_liter , additive_mof_36,are_you_sure_about_your_selction_mof_36, what_makes_you_so_sure_or_unsure_mof_36 )


Image('./ATIBOU02_cleansingle_linker0.png')


nutils.viewer('./ATIBOU02_clean.cif')


temperature_mof_37_Celsius  = 100.0 #@param {type:'number'}
time_mof_37_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_37 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_37 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_37 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_37 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_37 =  'CL' #@param {type:'string'}
concentration_metal_mof_37_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_37_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_37_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_37 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_37 =  'Found a similar MOF' #@param {type:'string'}
results['mof_37'] = {}
results['mof_37']['temperature']=temperature_mof_37_Celsius
results['mof_37']['time']=time_mof_37_hours
results['mof_37']['solvent1']=first_solvent_mof_37
results['mof_37']['solvent2']=second_solvent_mof_37
results['mof_37']['solvent3']=third_solvent_mof_37
results['mof_37']['additive']=additive_mof_37
results['mof_37']['counter']=counter_ion_mof_37
results['mof_37']['metal']=concentration_metal_mof_37_mol_per_liter
results['mof_37']['linker1']=concentration_first_linker_mof_37_mol_per_liter
results['mof_37']['linker2']=concentration_second_linker_mof_37_mol_per_liter
results['mof_37']['surely']=are_you_sure_about_your_selction_mof_37
results['mof_37']['additional']=what_makes_you_so_sure_or_unsure_mof_37


nutils.print_choice(temperature_mof_37_Celsius, time_mof_37_hours, first_solvent_mof_37,second_solvent_mof_37,third_solvent_mof_37 , counter_ion_mof_37, concentration_metal_mof_37_mol_per_liter, concentration_first_linker_mof_37_mol_per_liter,concentration_second_linker_mof_37_mol_per_liter , additive_mof_37,are_you_sure_about_your_selction_mof_37, what_makes_you_so_sure_or_unsure_mof_37 )


Image('./XAXQEU_SLsingle_linker1.png')


nutils.viewer('./XAXQEU_SL.cif')


temperature_mof_38_Celsius  = 100.0 #@param {type:'number'}
time_mof_38_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_38 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_38 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_38 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_38 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_38 =  'CL' #@param {type:'string'}
concentration_metal_mof_38_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_38_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_38_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_38 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_38 =  'Found a similar MOF' #@param {type:'string'}
results['mof_38'] = {}
results['mof_38']['temperature']=temperature_mof_38_Celsius
results['mof_38']['time']=time_mof_38_hours
results['mof_38']['solvent1']=first_solvent_mof_38
results['mof_38']['solvent2']=second_solvent_mof_38
results['mof_38']['solvent3']=third_solvent_mof_38
results['mof_38']['additive']=additive_mof_38
results['mof_38']['counter']=counter_ion_mof_38
results['mof_38']['metal']=concentration_metal_mof_38_mol_per_liter
results['mof_38']['linker1']=concentration_first_linker_mof_38_mol_per_liter
results['mof_38']['linker2']=concentration_second_linker_mof_38_mol_per_liter
results['mof_38']['surely']=are_you_sure_about_your_selction_mof_38
results['mof_38']['additional']=what_makes_you_so_sure_or_unsure_mof_38


nutils.print_choice(temperature_mof_38_Celsius, time_mof_38_hours, first_solvent_mof_38,second_solvent_mof_38,third_solvent_mof_38 , counter_ion_mof_38, concentration_metal_mof_38_mol_per_liter, concentration_first_linker_mof_38_mol_per_liter,concentration_second_linker_mof_38_mol_per_liter , additive_mof_38,are_you_sure_about_your_selction_mof_38, what_makes_you_so_sure_or_unsure_mof_38 )


Image('./MUVLUM_cleansingle_linker0.png')


Image('./MUVLUM_cleansingle_linker4.png')


nutils.viewer('./MUVLUM_clean.cif')


temperature_mof_39_Celsius  = 100.0 #@param {type:'number'}
time_mof_39_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_39 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_39 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_39 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_39 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_39 =  'CL' #@param {type:'string'}
concentration_metal_mof_39_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_39_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_39_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_39 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_39 =  'Found a similar MOF' #@param {type:'string'}
results['mof_39'] = {}
results['mof_39']['temperature']=temperature_mof_39_Celsius
results['mof_39']['time']=time_mof_39_hours
results['mof_39']['solvent1']=first_solvent_mof_39
results['mof_39']['solvent2']=second_solvent_mof_39
results['mof_39']['solvent3']=third_solvent_mof_39
results['mof_39']['additive']=additive_mof_39
results['mof_39']['counter']=counter_ion_mof_39
results['mof_39']['metal']=concentration_metal_mof_39_mol_per_liter
results['mof_39']['linker1']=concentration_first_linker_mof_39_mol_per_liter
results['mof_39']['linker2']=concentration_second_linker_mof_39_mol_per_liter
results['mof_39']['surely']=are_you_sure_about_your_selction_mof_39
results['mof_39']['additional']=what_makes_you_so_sure_or_unsure_mof_39


nutils.print_choice(temperature_mof_39_Celsius, time_mof_39_hours, first_solvent_mof_39,second_solvent_mof_39,third_solvent_mof_39 , counter_ion_mof_39, concentration_metal_mof_39_mol_per_liter, concentration_first_linker_mof_39_mol_per_liter,concentration_second_linker_mof_39_mol_per_liter , additive_mof_39,are_you_sure_about_your_selction_mof_39, what_makes_you_so_sure_or_unsure_mof_39 )


Image('./ADASOP_cleansingle_linker0.png')


nutils.viewer('./ADASOP_clean.cif')


temperature_mof_40_Celsius  = 100.0 #@param {type:'number'}
time_mof_40_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_40 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_40 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_40 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_40 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_40 =  'CL' #@param {type:'string'}
concentration_metal_mof_40_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_40_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_40_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_40 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_40 =  'Found a similar MOF' #@param {type:'string'}
results['mof_40'] = {}
results['mof_40']['temperature']=temperature_mof_40_Celsius
results['mof_40']['time']=time_mof_40_hours
results['mof_40']['solvent1']=first_solvent_mof_40
results['mof_40']['solvent2']=second_solvent_mof_40
results['mof_40']['solvent3']=third_solvent_mof_40
results['mof_40']['additive']=additive_mof_40
results['mof_40']['counter']=counter_ion_mof_40
results['mof_40']['metal']=concentration_metal_mof_40_mol_per_liter
results['mof_40']['linker1']=concentration_first_linker_mof_40_mol_per_liter
results['mof_40']['linker2']=concentration_second_linker_mof_40_mol_per_liter
results['mof_40']['surely']=are_you_sure_about_your_selction_mof_40
results['mof_40']['additional']=what_makes_you_so_sure_or_unsure_mof_40


nutils.print_choice(temperature_mof_40_Celsius, time_mof_40_hours, first_solvent_mof_40,second_solvent_mof_40,third_solvent_mof_40 , counter_ion_mof_40, concentration_metal_mof_40_mol_per_liter, concentration_first_linker_mof_40_mol_per_liter,concentration_second_linker_mof_40_mol_per_liter , additive_mof_40,are_you_sure_about_your_selction_mof_40, what_makes_you_so_sure_or_unsure_mof_40 )


Image('./OKIPUU_cleansingle_linker0.png')


Image('./OKIPUU_cleansingle_linker2.png')


nutils.viewer('./OKIPUU_clean.cif')


temperature_mof_41_Celsius  = 100.0 #@param {type:'number'}
time_mof_41_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_41 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_41 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_41 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_41 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_41 =  'CL' #@param {type:'string'}
concentration_metal_mof_41_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_41_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_41_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_41 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_41 =  'Found a similar MOF' #@param {type:'string'}
results['mof_41'] = {}
results['mof_41']['temperature']=temperature_mof_41_Celsius
results['mof_41']['time']=time_mof_41_hours
results['mof_41']['solvent1']=first_solvent_mof_41
results['mof_41']['solvent2']=second_solvent_mof_41
results['mof_41']['solvent3']=third_solvent_mof_41
results['mof_41']['additive']=additive_mof_41
results['mof_41']['counter']=counter_ion_mof_41
results['mof_41']['metal']=concentration_metal_mof_41_mol_per_liter
results['mof_41']['linker1']=concentration_first_linker_mof_41_mol_per_liter
results['mof_41']['linker2']=concentration_second_linker_mof_41_mol_per_liter
results['mof_41']['surely']=are_you_sure_about_your_selction_mof_41
results['mof_41']['additional']=what_makes_you_so_sure_or_unsure_mof_41


nutils.print_choice(temperature_mof_41_Celsius, time_mof_41_hours, first_solvent_mof_41,second_solvent_mof_41,third_solvent_mof_41 , counter_ion_mof_41, concentration_metal_mof_41_mol_per_liter, concentration_first_linker_mof_41_mol_per_liter,concentration_second_linker_mof_41_mol_per_liter , additive_mof_41,are_you_sure_about_your_selction_mof_41, what_makes_you_so_sure_or_unsure_mof_41 )


Image('./LATPIG_cleansingle_linker0.png')


nutils.viewer('./LATPIG_clean.cif')


temperature_mof_42_Celsius  = 100.0 #@param {type:'number'}
time_mof_42_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_42 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_42 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_42 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_42 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_42 =  'CL' #@param {type:'string'}
concentration_metal_mof_42_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_42_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_42_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_42 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_42 =  'Found a similar MOF' #@param {type:'string'}
results['mof_42'] = {}
results['mof_42']['temperature']=temperature_mof_42_Celsius
results['mof_42']['time']=time_mof_42_hours
results['mof_42']['solvent1']=first_solvent_mof_42
results['mof_42']['solvent2']=second_solvent_mof_42
results['mof_42']['solvent3']=third_solvent_mof_42
results['mof_42']['additive']=additive_mof_42
results['mof_42']['counter']=counter_ion_mof_42
results['mof_42']['metal']=concentration_metal_mof_42_mol_per_liter
results['mof_42']['linker1']=concentration_first_linker_mof_42_mol_per_liter
results['mof_42']['linker2']=concentration_second_linker_mof_42_mol_per_liter
results['mof_42']['surely']=are_you_sure_about_your_selction_mof_42
results['mof_42']['additional']=what_makes_you_so_sure_or_unsure_mof_42


nutils.print_choice(temperature_mof_42_Celsius, time_mof_42_hours, first_solvent_mof_42,second_solvent_mof_42,third_solvent_mof_42 , counter_ion_mof_42, concentration_metal_mof_42_mol_per_liter, concentration_first_linker_mof_42_mol_per_liter,concentration_second_linker_mof_42_mol_per_liter , additive_mof_42,are_you_sure_about_your_selction_mof_42, what_makes_you_so_sure_or_unsure_mof_42 )


Image('./UWOWAF_cleansingle_linker0.png')


nutils.viewer('./UWOWAF_clean.cif')


temperature_mof_43_Celsius  = 100.0 #@param {type:'number'}
time_mof_43_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_43 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_43 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_43 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_43 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_43 =  'CL' #@param {type:'string'}
concentration_metal_mof_43_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_43_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_43_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_43 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_43 =  'Found a similar MOF' #@param {type:'string'}
results['mof_43'] = {}
results['mof_43']['temperature']=temperature_mof_43_Celsius
results['mof_43']['time']=time_mof_43_hours
results['mof_43']['solvent1']=first_solvent_mof_43
results['mof_43']['solvent2']=second_solvent_mof_43
results['mof_43']['solvent3']=third_solvent_mof_43
results['mof_43']['additive']=additive_mof_43
results['mof_43']['counter']=counter_ion_mof_43
results['mof_43']['metal']=concentration_metal_mof_43_mol_per_liter
results['mof_43']['linker1']=concentration_first_linker_mof_43_mol_per_liter
results['mof_43']['linker2']=concentration_second_linker_mof_43_mol_per_liter
results['mof_43']['surely']=are_you_sure_about_your_selction_mof_43
results['mof_43']['additional']=what_makes_you_so_sure_or_unsure_mof_43


nutils.print_choice(temperature_mof_43_Celsius, time_mof_43_hours, first_solvent_mof_43,second_solvent_mof_43,third_solvent_mof_43 , counter_ion_mof_43, concentration_metal_mof_43_mol_per_liter, concentration_first_linker_mof_43_mol_per_liter,concentration_second_linker_mof_43_mol_per_liter , additive_mof_43,are_you_sure_about_your_selction_mof_43, what_makes_you_so_sure_or_unsure_mof_43 )


Image('./GUCHUJ_cleansingle_linker0.png')


nutils.viewer('./GUCHUJ_clean.cif')


temperature_mof_44_Celsius  = 100.0 #@param {type:'number'}
time_mof_44_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_44 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_44 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_44 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_44 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_44 =  'CL' #@param {type:'string'}
concentration_metal_mof_44_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_44_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_44_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_44 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_44 =  'Found a similar MOF' #@param {type:'string'}
results['mof_44'] = {}
results['mof_44']['temperature']=temperature_mof_44_Celsius
results['mof_44']['time']=time_mof_44_hours
results['mof_44']['solvent1']=first_solvent_mof_44
results['mof_44']['solvent2']=second_solvent_mof_44
results['mof_44']['solvent3']=third_solvent_mof_44
results['mof_44']['additive']=additive_mof_44
results['mof_44']['counter']=counter_ion_mof_44
results['mof_44']['metal']=concentration_metal_mof_44_mol_per_liter
results['mof_44']['linker1']=concentration_first_linker_mof_44_mol_per_liter
results['mof_44']['linker2']=concentration_second_linker_mof_44_mol_per_liter
results['mof_44']['surely']=are_you_sure_about_your_selction_mof_44
results['mof_44']['additional']=what_makes_you_so_sure_or_unsure_mof_44


nutils.print_choice(temperature_mof_44_Celsius, time_mof_44_hours, first_solvent_mof_44,second_solvent_mof_44,third_solvent_mof_44 , counter_ion_mof_44, concentration_metal_mof_44_mol_per_liter, concentration_first_linker_mof_44_mol_per_liter,concentration_second_linker_mof_44_mol_per_liter , additive_mof_44,are_you_sure_about_your_selction_mof_44, what_makes_you_so_sure_or_unsure_mof_44 )


Image('./GURTIX_chargedsingle_linker0.png')


Image('./GURTIX_chargedsingle_linker3.png')


nutils.viewer('./GURTIX_charged.cif')


temperature_mof_45_Celsius  = 100.0 #@param {type:'number'}
time_mof_45_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_45 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_45 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_45 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_45 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_45 =  'CL' #@param {type:'string'}
concentration_metal_mof_45_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_45_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_45_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_45 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_45 =  'Found a similar MOF' #@param {type:'string'}
results['mof_45'] = {}
results['mof_45']['temperature']=temperature_mof_45_Celsius
results['mof_45']['time']=time_mof_45_hours
results['mof_45']['solvent1']=first_solvent_mof_45
results['mof_45']['solvent2']=second_solvent_mof_45
results['mof_45']['solvent3']=third_solvent_mof_45
results['mof_45']['additive']=additive_mof_45
results['mof_45']['counter']=counter_ion_mof_45
results['mof_45']['metal']=concentration_metal_mof_45_mol_per_liter
results['mof_45']['linker1']=concentration_first_linker_mof_45_mol_per_liter
results['mof_45']['linker2']=concentration_second_linker_mof_45_mol_per_liter
results['mof_45']['surely']=are_you_sure_about_your_selction_mof_45
results['mof_45']['additional']=what_makes_you_so_sure_or_unsure_mof_45


nutils.print_choice(temperature_mof_45_Celsius, time_mof_45_hours, first_solvent_mof_45,second_solvent_mof_45,third_solvent_mof_45 , counter_ion_mof_45, concentration_metal_mof_45_mol_per_liter, concentration_first_linker_mof_45_mol_per_liter,concentration_second_linker_mof_45_mol_per_liter , additive_mof_45,are_you_sure_about_your_selction_mof_45, what_makes_you_so_sure_or_unsure_mof_45 )


Image('./IKUTOZ_cleansingle_linker0.png')


Image('./IKUTOZ_cleansingle_linker2.png')


nutils.viewer('./IKUTOZ_clean.cif')


temperature_mof_46_Celsius  = 100.0 #@param {type:'number'}
time_mof_46_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_46 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_46 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_46 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_46 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_46 =  'CL' #@param {type:'string'}
concentration_metal_mof_46_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_46_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_46_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_46 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_46 =  'Found a similar MOF' #@param {type:'string'}
results['mof_46'] = {}
results['mof_46']['temperature']=temperature_mof_46_Celsius
results['mof_46']['time']=time_mof_46_hours
results['mof_46']['solvent1']=first_solvent_mof_46
results['mof_46']['solvent2']=second_solvent_mof_46
results['mof_46']['solvent3']=third_solvent_mof_46
results['mof_46']['additive']=additive_mof_46
results['mof_46']['counter']=counter_ion_mof_46
results['mof_46']['metal']=concentration_metal_mof_46_mol_per_liter
results['mof_46']['linker1']=concentration_first_linker_mof_46_mol_per_liter
results['mof_46']['linker2']=concentration_second_linker_mof_46_mol_per_liter
results['mof_46']['surely']=are_you_sure_about_your_selction_mof_46
results['mof_46']['additional']=what_makes_you_so_sure_or_unsure_mof_46


nutils.print_choice(temperature_mof_46_Celsius, time_mof_46_hours, first_solvent_mof_46,second_solvent_mof_46,third_solvent_mof_46 , counter_ion_mof_46, concentration_metal_mof_46_mol_per_liter, concentration_first_linker_mof_46_mol_per_liter,concentration_second_linker_mof_46_mol_per_liter , additive_mof_46,are_you_sure_about_your_selction_mof_46, what_makes_you_so_sure_or_unsure_mof_46 )


Image('./ERULEK_cleansingle_linker0.png')


nutils.viewer('./ERULEK_clean.cif')


temperature_mof_47_Celsius  = 100.0 #@param {type:'number'}
time_mof_47_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_47 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_47 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_47 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_47 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_47 =  'CL' #@param {type:'string'}
concentration_metal_mof_47_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_47_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_47_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_47 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_47 =  'Found a similar MOF' #@param {type:'string'}
results['mof_47'] = {}
results['mof_47']['temperature']=temperature_mof_47_Celsius
results['mof_47']['time']=time_mof_47_hours
results['mof_47']['solvent1']=first_solvent_mof_47
results['mof_47']['solvent2']=second_solvent_mof_47
results['mof_47']['solvent3']=third_solvent_mof_47
results['mof_47']['additive']=additive_mof_47
results['mof_47']['counter']=counter_ion_mof_47
results['mof_47']['metal']=concentration_metal_mof_47_mol_per_liter
results['mof_47']['linker1']=concentration_first_linker_mof_47_mol_per_liter
results['mof_47']['linker2']=concentration_second_linker_mof_47_mol_per_liter
results['mof_47']['surely']=are_you_sure_about_your_selction_mof_47
results['mof_47']['additional']=what_makes_you_so_sure_or_unsure_mof_47


nutils.print_choice(temperature_mof_47_Celsius, time_mof_47_hours, first_solvent_mof_47,second_solvent_mof_47,third_solvent_mof_47 , counter_ion_mof_47, concentration_metal_mof_47_mol_per_liter, concentration_first_linker_mof_47_mol_per_liter,concentration_second_linker_mof_47_mol_per_liter , additive_mof_47,are_you_sure_about_your_selction_mof_47, what_makes_you_so_sure_or_unsure_mof_47 )


Image('./DITTEH_cleansingle_linker1.png')


nutils.viewer('./DITTEH_clean.cif')


temperature_mof_48_Celsius  = 100.0 #@param {type:'number'}
time_mof_48_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_48 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_48 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_48 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_48 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_48 =  'CL' #@param {type:'string'}
concentration_metal_mof_48_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_48_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_48_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_48 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_48 =  'Found a similar MOF' #@param {type:'string'}
results['mof_48'] = {}
results['mof_48']['temperature']=temperature_mof_48_Celsius
results['mof_48']['time']=time_mof_48_hours
results['mof_48']['solvent1']=first_solvent_mof_48
results['mof_48']['solvent2']=second_solvent_mof_48
results['mof_48']['solvent3']=third_solvent_mof_48
results['mof_48']['additive']=additive_mof_48
results['mof_48']['counter']=counter_ion_mof_48
results['mof_48']['metal']=concentration_metal_mof_48_mol_per_liter
results['mof_48']['linker1']=concentration_first_linker_mof_48_mol_per_liter
results['mof_48']['linker2']=concentration_second_linker_mof_48_mol_per_liter
results['mof_48']['surely']=are_you_sure_about_your_selction_mof_48
results['mof_48']['additional']=what_makes_you_so_sure_or_unsure_mof_48


nutils.print_choice(temperature_mof_48_Celsius, time_mof_48_hours, first_solvent_mof_48,second_solvent_mof_48,third_solvent_mof_48 , counter_ion_mof_48, concentration_metal_mof_48_mol_per_liter, concentration_first_linker_mof_48_mol_per_liter,concentration_second_linker_mof_48_mol_per_liter , additive_mof_48,are_you_sure_about_your_selction_mof_48, what_makes_you_so_sure_or_unsure_mof_48 )


Image('./LAWHUP_cleansingle_linker0.png')


nutils.viewer('./LAWHUP_clean.cif')


temperature_mof_49_Celsius  = 100.0 #@param {type:'number'}
time_mof_49_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_49 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_49 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_49 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_49 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_49 =  'CL' #@param {type:'string'}
concentration_metal_mof_49_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_49_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_49_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_49 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_49 =  'Found a similar MOF' #@param {type:'string'}
results['mof_49'] = {}
results['mof_49']['temperature']=temperature_mof_49_Celsius
results['mof_49']['time']=time_mof_49_hours
results['mof_49']['solvent1']=first_solvent_mof_49
results['mof_49']['solvent2']=second_solvent_mof_49
results['mof_49']['solvent3']=third_solvent_mof_49
results['mof_49']['additive']=additive_mof_49
results['mof_49']['counter']=counter_ion_mof_49
results['mof_49']['metal']=concentration_metal_mof_49_mol_per_liter
results['mof_49']['linker1']=concentration_first_linker_mof_49_mol_per_liter
results['mof_49']['linker2']=concentration_second_linker_mof_49_mol_per_liter
results['mof_49']['surely']=are_you_sure_about_your_selction_mof_49
results['mof_49']['additional']=what_makes_you_so_sure_or_unsure_mof_49


nutils.print_choice(temperature_mof_49_Celsius, time_mof_49_hours, first_solvent_mof_49,second_solvent_mof_49,third_solvent_mof_49 , counter_ion_mof_49, concentration_metal_mof_49_mol_per_liter, concentration_first_linker_mof_49_mol_per_liter,concentration_second_linker_mof_49_mol_per_liter , additive_mof_49,are_you_sure_about_your_selction_mof_49, what_makes_you_so_sure_or_unsure_mof_49 )


Image('./ISUGIN_cleansingle_linker0.png')


nutils.viewer('./ISUGIN_clean.cif')


temperature_mof_50_Celsius  = 100.0 #@param {type:'number'}
time_mof_50_hours  = 25.0 #@param {type:'number'}
first_solvent_mof_50 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
second_solvent_mof_50 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
third_solvent_mof_50 = 'N-methylformamide' #@param ['None','water', '1,4-dioxane', 'N-methylformamide', 'ethane-1,2-diol', 'benzene', 'butane-1,4-diamine', '1-bis(butylsulfanyl)phosphorylsulfanylbutane', 'methanol', 'pyridine','N,N-diethylformamide (DEF)', 'butan-1-ol','dichloromethane','1-methylpyrrolidin-2-one (NMP)','ethoxyethane','2-methoxy-2-methylpropane','propan-2-one','chloroform','chloroform','oxolane','2-propan-2-yloxypropane','ethyl acetate','ethanol','acetonitrile', '1,2-dimethoxyethane', '1,2-dichloroethane','DMF','DMSO','pyrrolidin-2-one','N,N-dimethylacetamide','2,2,2-trifluoroethanol']
additive_mof_50 = 'no additive' #@param ['no additive', 'acid', 'base']
counter_ion_mof_50 =  'CL' #@param {type:'string'}
concentration_metal_mof_50_mol_per_liter  = 10.0 #@param {type:'number'}
concentration_first_linker_mof_50_mol_per_liter  = 12.0 #@param {type:'number'}
concentration_second_linker_mof_50_mol_per_liter  = 0.0 #@param {type:'number'}
are_you_sure_about_your_selction_mof_50 = 'no' #@param ['no', 'yes']
what_makes_you_so_sure_or_unsure_mof_50 =  'Found a similar MOF' #@param {type:'string'}
results['mof_50'] = {}
results['mof_50']['temperature']=temperature_mof_50_Celsius
results['mof_50']['time']=time_mof_50_hours
results['mof_50']['solvent1']=first_solvent_mof_50
results['mof_50']['solvent2']=second_solvent_mof_50
results['mof_50']['solvent3']=third_solvent_mof_50
results['mof_50']['additive']=additive_mof_50
results['mof_50']['counter']=counter_ion_mof_50
results['mof_50']['metal']=concentration_metal_mof_50_mol_per_liter
results['mof_50']['linker1']=concentration_first_linker_mof_50_mol_per_liter
results['mof_50']['linker2']=concentration_second_linker_mof_50_mol_per_liter
results['mof_50']['surely']=are_you_sure_about_your_selction_mof_50
results['mof_50']['additional']=what_makes_you_so_sure_or_unsure_mof_50


nutils.print_choice(temperature_mof_50_Celsius, time_mof_50_hours, first_solvent_mof_50,second_solvent_mof_50,third_solvent_mof_50 , counter_ion_mof_50, concentration_metal_mof_50_mol_per_liter, concentration_first_linker_mof_50_mol_per_liter,concentration_second_linker_mof_50_mol_per_liter , additive_mof_50,are_you_sure_about_your_selction_mof_50, what_makes_you_so_sure_or_unsure_mof_50 )


